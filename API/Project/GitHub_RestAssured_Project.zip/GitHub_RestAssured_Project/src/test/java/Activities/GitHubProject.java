package Activities;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import org.testng.Reporter;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.RestAssured.given;
import static org.hamcrest.core.IsEqual.equalTo;

public class GitHubProject {

    RequestSpecification requestSpec;
    ResponseSpecification responseSpec;
    String sshKey = "ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIPDxCbBWEiUJ39CQ/9+DavvzXRc1b15mNRHyTKpcLlgf";
    int sshKeyId;
    String baseUri="https://api.github.com";
    @BeforeClass
    public void setUp() {
        requestSpec = new RequestSpecBuilder()
                .addHeader("Authorization", "token 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")
                .addHeader("Content-Type", "application/json")
                .build();

        responseSpec = new ResponseSpecBuilder()
                .expectBody("key", equalTo(sshKey))
                .expectBody("title", equalTo("TestApiKey"))
                .build();
    }

    @Test(priority = 1)
    public void postRequest() {
        Map<String, String> map = new HashMap<>();
        map.put("key", sshKey);
        map.put("title", "TestApiKey");
        Response response = given().spec(requestSpec)
                .body(map).when().post(baseUri+"/users/keys");
        System.out.println(requestSpec.toString());
        System.out.println(response.prettyPeek());
        sshKeyId = response.then().extract().path("id");
        response.then().statusCode(201).spec(responseSpec);
    }
    @Test(priority = 2)
    public void getRequest() {

        Response response = given().spec(requestSpec)
                .pathParam("keyId", sshKeyId)
                .when().get("/user/keys/{keyId}");
        response.then().statusCode(200).spec(responseSpec);
        Reporter.log(response.toString());

    }

    @Test(priority = 3)
    public void deleteRequest() {

        Response response = given().spec(requestSpec)
                .pathParam("keyId", sshKeyId)
                .when().delete("/user/keys/{keyId}");
        response.then().statusCode(204).spec(responseSpec);
        Reporter.log(response.toString());
    }
}