package Google_Task;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.List;

public class Activity {
    AndroidDriver driver;
    String tasks[] = {"Complete Activity with Google Tasks",
            "Complete Activity with Google Keep", "Complete the second Activity Google Keep"};


    @BeforeClass
    public void setUp() throws MalformedURLException {
        UiAutomator2Options options = new UiAutomator2Options();
        options.setPlatformName("android");
        options.setAutomationName("UiAutomator2");
        options.setAppPackage("com.google.android.apps.tasks");
        options.setAppActivity(".ui.TaskListsActivity");
        options.noReset();

        URL serverURL = new URL("http://localhost:4723/wd/hub");

        driver = new AndroidDriver(serverURL, options);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
    }

    @Test
    public void addTask() {

        for (String taskList : tasks) {
            driver.findElement(AppiumBy.accessibilityId("Create new task")).click();
            driver.findElement(AppiumBy.id("com.google.android.apps.tasks:id/add_task_title")).
                    sendKeys(taskList);
            driver.findElement(AppiumBy.id("com.google.android.apps.tasks:id/add_task_done")).click();
        }
        //Assertion part
        List<WebElement> taskLists= driver.findElements(AppiumBy.id("com.google.android.apps.tasks:id/task_name"));
        int i=2;
        for (WebElement element:taskLists) {
            Assert.assertEquals(tasks[i], element.getText());
            i--;
        }

    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}