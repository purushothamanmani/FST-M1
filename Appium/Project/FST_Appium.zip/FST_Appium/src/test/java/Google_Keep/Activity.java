package Google_Keep;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;

public class Activity {
    AndroidDriver driver;
    String noteValue = "Appium project";

    @BeforeClass
    public void setUp() throws MalformedURLException {
        UiAutomator2Options options = new UiAutomator2Options();
        options.setPlatformName("android");
        options.setAutomationName("UiAutomator2");
        options.setAppPackage("com.google.android.keep");
        options.setAppActivity(".activities.BrowseActivity");
        options.noReset();

        URL serverURL = new URL("http://localhost:4723/wd/hub");

        driver = new AndroidDriver(serverURL, options);
    }

    @Test
    public void addNotes() {

        // Create new notes
        driver.findElement(AppiumBy.id("com.google.android.keep:id/new_note_button")).click();
        driver.findElement(AppiumBy.id("com.google.android.keep:id/editable_title")).
                sendKeys("g_Keep1");
        driver.findElement(AppiumBy.id("com.google.android.keep:id/edit_note_text")).
                sendKeys(noteValue);
        driver.findElement(AppiumBy.accessibilityId("Navigate up")).click();

        //Assertion part
        String noteText = driver.findElement(AppiumBy.id("com.google.android.keep:id/index_note_text_description")).getText();
        Assert.assertEquals(noteText, noteValue);

    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}