package To_Do_List;

import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.options.UiAutomator2Options;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;
import java.util.List;

public class Activity {
    AndroidDriver driver;
    String to_Do_Lists[] = {"Add tasks to list", "Get number of tasks", "Clear the list"};


    @BeforeClass
    public void setUp() throws MalformedURLException {
        UiAutomator2Options options = new UiAutomator2Options();
        options.setPlatformName("android");
        options.setAutomationName("UiAutomator2");
        options.setAppPackage("com.android.chrome");
        options.setAppActivity("com.google.android.apps.chrome.Main");
        options.noReset();

        URL serverURL = new URL("http://localhost:4723/wd/hub");

        driver = new AndroidDriver(serverURL, options);
        driver.get("https://www.training-support.net/selenium");
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
    }

    @Test
    public void toDoList() {
        String UiScrollable = "UiScrollable(UiSelector().scrollable(true))";
        driver.findElement(AppiumBy.androidUIAutomator(UiScrollable + ".scrollTextIntoView(\"To-Do List\")"));
        driver.findElement(AppiumBy.accessibilityId("To-Do List Elements get added at runtime!")).click();
        // Add the list
        for (String to_Do_List : to_Do_Lists) {
            driver.findElement(AppiumBy.className("android.widget.EditText"))
                    .sendKeys(to_Do_List);
            driver.findElement(AppiumBy.xpath("(//android.view.View/android.widget.Button)[3]")).click();
        }
        // Strike out the List
        List<WebElement> taskLists= driver.findElements(AppiumBy.className("android.widget.CheckBox"));
        for (WebElement element:taskLists) {
           element.click();
        }
        Assert.assertEquals(5,taskLists.size());

        // Clear the list
        driver.findElement(AppiumBy.xpath("(//android.view.View/android.widget.Button)[8]")).click();
        List<WebElement> taskLists1= driver.findElements(AppiumBy.className("android.widget.CheckBox"));
        Assert.assertEquals(4,taskLists1.size());
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}