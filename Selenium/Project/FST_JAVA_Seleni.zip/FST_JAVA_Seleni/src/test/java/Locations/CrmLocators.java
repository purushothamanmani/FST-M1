package Locations;

public class CrmLocators {
    public static String crmLogo = "//div[@class='companylogo']/img";
    public static String crmCopyText = "//*[contains(@id,'admin_options')]";
    public static String crmUserName = "(//*[contains(@class,'input-group')]//input)[1]";
    public static String crmPassword = "(//*[contains(@class,'input-group')]//input)[2]";
    public static String crmHomePage = "//*[contains(@id,'pagecontent')]";
    public static String crmLoginButton = "//*[contains(@id,'bigbutton')]";
    public static String crmMenuBar = "(//*[contains(@class,'container-fluid')])[1]";
    public static String crmActivityMenu = "//*[contains(text(),'Activities')]";
    public static String crmSalesMenu = "(.//*[contains(text(),'Sales')])[1]";
    public static String crmLeadMenu = "//div[@id='toolbar']//ul/li[2]//li[5]";
    public static String crmLeadsIcon = "(//*[contains(@class,'suitepicon-action-info')])[1]";
    public static String phoneNum = "(//*[contains(@class,'phone')])[11]";
    public static String accountName = "//*[contains(@class,'oddListRowS1')]/td[3]";
    public static String crmAccountMenu = "//div[@id='toolbar']//ul/li[2]//li[2]";
    public static String crmLeadName = "//td[3][contains(@class,' inlineEdit')]";
    public static String crmLeadUser = "//td[8][contains(@class,' inlineEdit')]";



}