package SeleniumProject;

import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static browserInitialize.BrowserIntialize.browseConfig;


public class Activity1 {
    static WebDriver driver= browseConfig();
    @Test
    public  static void verifyTitle(){
        Assert.assertEquals("SuiteCRM",driver.getTitle());
    }
    @AfterTest
    public static void closeBrowser() {
        driver.quit();
    }

}
