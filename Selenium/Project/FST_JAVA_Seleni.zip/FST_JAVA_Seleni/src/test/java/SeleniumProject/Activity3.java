package SeleniumProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Locations.CrmLocators.crmCopyText;
import static browserInitialize.BrowserIntialize.browseConfig;

public class Activity3 {
    static WebDriver driver = browseConfig();
    @Test
    public  static void getCopyRightText(){
        String copyRightText= driver.findElement(By.xpath(crmCopyText)).getText();
        System.out.println("Copy right text value: "+copyRightText);
    }
    @AfterTest
    public static void closeBrowser() {
        driver.quit();
    }
}
