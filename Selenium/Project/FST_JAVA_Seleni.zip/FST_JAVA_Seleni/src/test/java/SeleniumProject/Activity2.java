package SeleniumProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Locations.CrmLocators.crmLogo;
import static browserInitialize.BrowserIntialize.*;

public class Activity2 {
    static WebDriver driver = browseConfig();

    @Test
    public static void getUrl() {
        String url = driver.findElement(By.xpath(crmLogo)).getAttribute("src");
        System.out.println("Given Url: " + url);
    }
    @AfterTest
    public static void closeBrowser() {
        driver.quit();
    }
}
