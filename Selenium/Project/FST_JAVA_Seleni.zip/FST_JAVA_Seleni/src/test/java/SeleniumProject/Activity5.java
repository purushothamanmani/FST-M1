package SeleniumProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Locations.CrmLocators.crmMenuBar;
import static browserInitialize.BrowserIntialize.browseConfig;
import static browserInitialize.BrowserIntialize.loginScreen;

public class Activity5 {

    static WebDriver driver = browseConfig();
    @Test
    public static void getMenuColor() {
        loginScreen();
        WebElement element = driver.findElement(By.xpath(crmMenuBar));
        System.out.println("Menu color is: "+element.getCssValue("color"));
    }
    @AfterTest
    public static void closeBrowser() {
        driver.quit();
    }

}
