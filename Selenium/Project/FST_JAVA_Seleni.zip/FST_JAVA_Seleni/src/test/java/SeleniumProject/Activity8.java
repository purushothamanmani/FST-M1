package SeleniumProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.List;

import static Locations.CrmLocators.*;
import static browserInitialize.BrowserIntialize.browseConfig;
import static browserInitialize.BrowserIntialize.loginScreen;

public class Activity8 {

    static WebDriver driver = browseConfig();

    @Test
    public static void fiveOddRows() throws InterruptedException {
        loginScreen();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
        WebElement salesMenu = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(crmSalesMenu)));
        salesMenu.click();
        driver.findElement(By.xpath(crmAccountMenu)).click();
        Thread.sleep(4000);
        List<WebElement> listValue= driver.findElements(By.xpath(accountName));
        for(int i=0;i<listValue.size();i++){
            if(i<5) {
                System.out.println("Name: " + listValue.get(i).getText());
            }
        }
    }

    @AfterTest
    public static void closeBrowser() {
        driver.quit();
    }

}
