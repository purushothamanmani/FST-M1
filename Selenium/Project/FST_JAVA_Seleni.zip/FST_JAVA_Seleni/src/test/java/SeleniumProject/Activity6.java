package SeleniumProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Locations.CrmLocators.crmActivityMenu;
import static browserInitialize.BrowserIntialize.browseConfig;
import static browserInitialize.BrowserIntialize.loginScreen;

public class Activity6 {

    static WebDriver driver = browseConfig();
    @Test
    public static void elementIsExist() {
        loginScreen();
        Boolean  isPresent = driver.findElements(By.xpath(crmActivityMenu)).size()>0;
        Assert.assertTrue(isPresent);
    }
    @AfterTest
    public static void closeBrowser() {
        driver.quit();
    }

}
