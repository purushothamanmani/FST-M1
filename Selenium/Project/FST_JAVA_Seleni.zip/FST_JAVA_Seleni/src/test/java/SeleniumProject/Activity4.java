package SeleniumProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import static Locations.CrmLocators.*;
import static browserInitialize.BrowserIntialize.browseConfig;
import static browserInitialize.BrowserIntialize.loginScreen;

public class Activity4 {

    static WebDriver driver = browseConfig();

    @Test
    public static void homePageScreen() {
        loginScreen();
        WebElement element = driver.findElement(By.xpath(crmHomePage));
        Assert.assertTrue(element.isDisplayed());
    }

    @AfterTest
    public static void closeBrowser() {
        driver.quit();
    }

}
