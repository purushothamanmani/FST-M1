package SeleniumProject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

import java.time.Duration;

import static Locations.CrmLocators.*;
import static browserInitialize.BrowserIntialize.browseConfig;
import static browserInitialize.BrowserIntialize.loginScreen;

public class Activity7 {

    static WebDriver driver = browseConfig();

    @Test
    public static void ReadPopUpContent() throws InterruptedException {
        loginScreen();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(50));
        WebElement salesMenu = wait.until(ExpectedConditions.elementToBeClickable(By.xpath(crmSalesMenu)));
        salesMenu.click();
        driver.findElement(By.xpath(crmLeadMenu)).click();
        Thread.sleep(4000);
        WebElement element1=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(crmLeadsIcon)));
        element1.click();
        WebElement element=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath(phoneNum)));
        System.out.println("Mobile Number: "+element.getText());

    }

    @AfterTest
    public static void closeBrowser() {
        driver.quit();
    }

}
