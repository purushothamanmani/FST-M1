package browserInitialize;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeTest;

import java.time.Duration;

import static Locations.CrmLocators.*;

public class BrowserIntialize {
    static WebDriver driver;

    @BeforeTest
    public static WebDriver browseConfig() {
        WebDriverManager.firefoxdriver().setup();
        driver = new FirefoxDriver();
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        driver.get("https://alchemy.hguy.co/crm/");
        driver.manage().window().maximize();
        return driver;
    }

    public static void loginScreen() {
        driver.findElement(By.xpath(crmUserName)).sendKeys("admin");
        driver.findElement(By.xpath(crmPassword)).sendKeys("pa$$w0rd");
        driver.findElement(By.xpath(crmLoginButton)).click();
    }
}
