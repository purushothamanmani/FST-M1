from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.service import Service as FirefoxService
from webdriver_manager.firefox import GeckoDriverManager
from Activity.Locators.Locator import Locator
service = FirefoxService(GeckoDriverManager().install())
locator = Locator()
with webdriver.Firefox(service=service) as driver:

    driver.get("https://alchemy.hguy.co/crm")
    elementUser = driver.find_element(By.XPATH, locator.crmUserName)
    elementUser.send_keys("admin")
    elementPass = driver.find_element(By.XPATH, locator.crmPassword)
    elementPass.send_keys("pa$$w0rd")
    elementLogin = driver.find_element(By.XPATH, locator.crmLoginButton)
    elementLogin.click()
    elements = driver.find_elements(By.XPATH, locator.crmMenuBar)
    for element in elements:
        print("Color of the", element.text, "Menu: ", element.value_of_css_property("color"))

    driver.quit()
