import time

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.firefox.service import Service as FirefoxService
from webdriver_manager.firefox import GeckoDriverManager
from Activity.Locators.Locator import Locator
from selenium.webdriver.common.action_chains import ActionChains

service = FirefoxService(GeckoDriverManager().install())
locator = Locator()
with webdriver.Firefox(service=service) as driver:
    driver.get("https://alchemy.hguy.co/crm")
    elementUser = driver.find_element(By.XPATH, locator.crmUserName)
    elementUser.send_keys("admin")
    elementPass = driver.find_element(By.XPATH, locator.crmPassword)
    elementPass.send_keys("pa$$w0rd")
    elementLogin = driver.find_element(By.XPATH, locator.crmLoginButton)
    elementLogin.click()

    act = ActionChains(driver)
    salesMenu = driver.find_element(By.XPATH, locator.crmSalesMenu)
    act.move_to_element(salesMenu).perform()

    element = driver.find_element(By.XPATH, locator.crmLeadMenu)
    element.click()
    time.sleep(5)
    elements = driver.find_elements(By.XPATH, locator.crmLeadName)
    for i in range(0, 10):
        print("Lead Name is: ", elements[i].text)

    elementsUser = driver.find_elements(By.XPATH, locator.crmLeadUser)
    for i in range(0, 10):
        print("User Name is: ", elementsUser[i].text)

    driver.quit()
